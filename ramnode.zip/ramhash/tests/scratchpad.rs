use ramhash::{lanes_for_intensity, mine_scratchpad, mine_scratchpad_ondemand, verify_scratchpad, ScratchpadParams};

fn test_params() -> ScratchpadParams {
    ScratchpadParams {
        scratchpad_bytes: 1 << 16, // 64 KiB -- fast for tests
        rounds: 64,
    }
}

#[test]
fn mining_is_deterministic() {
    let params = test_params();
    let h1 = mine_scratchpad(b"header", 42, &params);
    let h2 = mine_scratchpad(b"header", 42, &params);
    assert_eq!(h1, h2);
}

#[test]
fn verify_matches_mine() {
    let params = test_params();
    let h1 = mine_scratchpad(b"header", 42, &params);
    let h2 = verify_scratchpad(b"header", 42, &params);
    assert_eq!(h1, h2);
}

#[test]
fn different_nonce_differs() {
    let params = test_params();
    let h1 = mine_scratchpad(b"header", 1, &params);
    let h2 = mine_scratchpad(b"header", 2, &params);
    assert_ne!(h1, h2);
}

#[test]
fn different_header_differs() {
    let params = test_params();
    let h1 = mine_scratchpad(b"header-a", 1, &params);
    let h2 = mine_scratchpad(b"header-b", 1, &params);
    assert_ne!(h1, h2);
}

#[test]
fn scratchpad_fill_touches_every_slot_with_high_entropy() {
    // Sanity check on the fill chain itself: over a modest scratchpad,
    // the low byte of each filled item should look roughly uniform, not
    // degenerate (guards against a repeat of the GPU cross-group mixing
    // bug found earlier in this project).
    use ramhash::fill_scratchpad;
    use std::collections::HashSet;

    let seed = ramhash::mine_scratchpad(b"seed-header", 0, &ScratchpadParams { scratchpad_bytes: 64, rounds: 0 });
    let len = 4096u32;
    let pad = fill_scratchpad(seed, len);
    let mut seen = HashSet::new();
    for item in &pad {
        seen.insert(item[0]);
    }
    // With 4096 samples of one byte (256 possible values), expect most
    // values to appear at least once if the chain has real entropy.
    assert!(seen.len() > 200, "only {} distinct first-bytes across {} fill steps -- looks degenerate", seen.len(), len);
}

#[test]
fn ondemand_matches_honest_mining() {
    let params = ScratchpadParams { scratchpad_bytes: 1 << 14, rounds: 200 }; // 16 KiB, small enough that on-demand replay is fast in a test
    for nonce in [0u64, 1, 42, 999999] {
        let (honest, _) = (mine_scratchpad(b"header", nonce, &params), ());
        let (ondemand, stats) = mine_scratchpad_ondemand(b"header", nonce, &params);
        assert_eq!(honest, ondemand, "on-demand mining diverged from honest mining for nonce {nonce}");
        assert!(stats.peak_cache_entries <= params.scratchpad_len() as usize);
    }
}

#[test]
fn different_rounds_produce_different_results() {
    let mut params = test_params();
    params.rounds = 8;
    let h1 = mine_scratchpad(b"header", 1, &params);
    params.rounds = 16;
    let h2 = mine_scratchpad(b"header", 1, &params);
    assert_ne!(h1, h2);
}

#[test]
fn intensity_level_10_uses_full_max() {
    assert_eq!(lanes_for_intensity(10, 16), 16);
    assert_eq!(lanes_for_intensity(10, 1), 1);
}

#[test]
fn intensity_level_1_never_collapses_to_zero() {
    assert_eq!(lanes_for_intensity(1, 1), 1);
    assert_eq!(lanes_for_intensity(1, 4), 1);
    assert_eq!(lanes_for_intensity(1, 16), 2);
}

#[test]
fn intensity_is_monotonic_nondecreasing_in_level() {
    let max = 16;
    let mut prev = 0;
    for level in 1..=10u8 {
        let lanes = lanes_for_intensity(level, max);
        assert!(lanes >= prev, "level {level} gave {lanes} lanes, less than level {}'s {prev}", level - 1);
        prev = lanes;
    }
}

#[test]
fn intensity_out_of_range_levels_clamp() {
    assert_eq!(lanes_for_intensity(0, 16), lanes_for_intensity(1, 16));
    assert_eq!(lanes_for_intensity(255, 16), lanes_for_intensity(10, 16));
}
