use ramhash::{mine_hash, mine_hash_batch, verify_hash, Cache, Dataset, Params, Variant};

/// Small parameters shared by all tests -- fast to run in CI, not a
/// mainnet proposal. Kept in one place so every test exercises the same
/// configuration unless it specifically needs otherwise.
fn test_params(variant: Variant) -> Params {
    Params {
        dataset_bytes: 1 << 20,  // 1 MiB -> small enough to build instantly
        cache_bytes: 1 << 14,    // 16 KiB
        dataset_parents: 8,
        lookups_per_hash: 8,
        variant,
    }
}

#[test]
fn cache_generation_is_deterministic() {
    let params = test_params(Variant::A);
    let c1 = Cache::generate(b"test-seed", &params);
    let c2 = Cache::generate(b"test-seed", &params);
    assert_eq!(c1.items, c2.items);
}

#[test]
fn cache_generation_differs_by_seed() {
    let params = test_params(Variant::A);
    let c1 = Cache::generate(b"seed-a", &params);
    let c2 = Cache::generate(b"seed-b", &params);
    assert_ne!(c1.items, c2.items);
}

#[test]
fn dataset_item_generation_is_deterministic() {
    let params = test_params(Variant::A);
    let cache = Cache::generate(b"test-seed", &params);
    let a = ramhash::dataset::generate_item(&cache, 42, params.dataset_parents);
    let b = ramhash::dataset::generate_item(&cache, 42, params.dataset_parents);
    assert_eq!(a, b);
}

#[test]
fn dataset_item_generation_differs_by_index() {
    let params = test_params(Variant::A);
    let cache = Cache::generate(b"test-seed", &params);
    let a = ramhash::dataset::generate_item(&cache, 1, params.dataset_parents);
    let b = ramhash::dataset::generate_item(&cache, 2, params.dataset_parents);
    assert_ne!(a, b);
}

#[test]
fn dataset_len_and_cache_len_are_powers_of_two() {
    let params = test_params(Variant::A);
    assert!(params.dataset_len().is_power_of_two());
    assert!(params.cache_len().is_power_of_two());
}

/// The core correctness invariant of the whole `Storage` abstraction:
/// full dataset, partial dataset, and cache-only regeneration must all
/// produce byte-identical PoW output for the same (header, nonce).
/// Storage mode may only ever change *performance*, never the result --
/// otherwise "verification" and "mining" would not be checking the same
/// thing.
#[test]
fn all_storage_modes_agree_on_the_same_hash() {
    for variant in [Variant::A, Variant::B, Variant::C, Variant::CheapMix] {
        let params = test_params(variant);
        let cache = Cache::generate(b"agreement-seed", &params);
        let header = b"fake-block-header";
        let nonce = 123456789u64;

        let full = Dataset::build_full(&cache, &params);
        let partial_75 = Dataset::build_partial(&cache, &params, 0.75);
        let partial_25 = Dataset::build_partial(&cache, &params, 0.25);
        let cache_only = Dataset::cache_only(&cache, &params);

        let h_full = mine_hash(header, nonce, &full, &params);
        let h_partial_75 = mine_hash(header, nonce, &partial_75, &params);
        let h_partial_25 = mine_hash(header, nonce, &partial_25, &params);
        let h_cache_only = mine_hash(header, nonce, &cache_only, &params);
        let h_verify = verify_hash(header, nonce, &cache, &params);

        assert_eq!(h_full, h_partial_75, "variant {:?}: partial(75%) disagrees with full", variant);
        assert_eq!(h_full, h_partial_25, "variant {:?}: partial(25%) disagrees with full", variant);
        assert_eq!(h_full, h_cache_only, "variant {:?}: cache-only disagrees with full", variant);
        assert_eq!(h_full, h_verify, "variant {:?}: verify_hash disagrees with full mining", variant);
    }
}

#[test]
fn mutating_header_changes_the_hash() {
    let params = test_params(Variant::A);
    let cache = Cache::generate(b"tamper-seed", &params);
    let full = Dataset::build_full(&cache, &params);

    let h1 = mine_hash(b"header-a", 1, &full, &params);
    let h2 = mine_hash(b"header-b", 1, &full, &params);
    assert_ne!(h1, h2);
}

#[test]
fn mutating_nonce_changes_the_hash() {
    let params = test_params(Variant::A);
    let cache = Cache::generate(b"tamper-seed-2", &params);
    let full = Dataset::build_full(&cache, &params);

    let h1 = mine_hash(b"header", 1, &full, &params);
    let h2 = mine_hash(b"header", 2, &full, &params);
    assert_ne!(h1, h2);
}

#[test]
fn meets_target_is_correct_for_boundary_cases() {
    let hash = [0u8; 64];
    let mut target = [0u8; 64];
    assert!(ramhash::meets_target(&hash, &target), "equal hash/target must pass (<=)");

    target[63] = 1;
    assert!(ramhash::meets_target(&hash, &target), "hash below target must pass");

    let mut hash2 = [0u8; 64];
    hash2[0] = 1;
    let target2 = [0u8; 64];
    assert!(!ramhash::meets_target(&hash2, &target2), "hash above target must fail");
}

#[test]
fn batched_mining_matches_single_chain_mining() {
    let params = test_params(Variant::CheapMix);
    let cache = Cache::generate(b"batch-seed", &params);
    let full = Dataset::build_full(&cache, &params);
    let header = b"batch-header";
    let nonces = [1u64, 2, 3, 4, 7, 1000, 999999];

    let batched = mine_hash_batch(header, &nonces, &full, &params);
    for (i, &nonce) in nonces.iter().enumerate() {
        let single = mine_hash(header, nonce, &full, &params);
        assert_eq!(batched[i], single, "chain {i} (nonce {nonce}) diverged between batch and single-chain mining");
    }
}

#[test]
fn variants_produce_different_hashes_for_the_same_input() {
    let cache_seed = b"variant-diff-seed";
    let header = b"header";
    let nonce = 1u64;

    let pa = test_params(Variant::A);
    let pb = test_params(Variant::B);
    let pc = test_params(Variant::C);

    let ca = Cache::generate(cache_seed, &pa);
    let cb = Cache::generate(cache_seed, &pb);
    let cc = Cache::generate(cache_seed, &pc);

    let da = Dataset::build_full(&ca, &pa);
    let db = Dataset::build_full(&cb, &pb);
    let dc = Dataset::build_full(&cc, &pc);

    let ha = mine_hash(header, nonce, &da, &pa);
    let hb = mine_hash(header, nonce, &db, &pb);
    let hc = mine_hash(header, nonce, &dc, &pc);

    assert_ne!(ha, hb);
    assert_ne!(ha, hc);
    assert_ne!(hb, hc);
}
