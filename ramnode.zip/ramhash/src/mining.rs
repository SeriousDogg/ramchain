use crate::cache::Cache;
use crate::dataset::Dataset;
use crate::item::{first_u32, item_from_hash, Item};
use crate::params::Params;
use crate::variant::mix_step;

/// One PoW attempt: header + nonce -> chained, data-dependent lookups
/// into `dataset` -> final digest. `dataset` can be any `Storage` mode
/// (full/partial/cache-only) -- that choice is exactly what the "attack
/// benchmarks" vary, and the mining loop itself is identical regardless.
pub fn mine_hash(header: &[u8], nonce: u64, dataset: &Dataset, params: &Params) -> Item {
    let mut hasher = blake3::Hasher::new();
    hasher.update(header);
    hasher.update(&nonce.to_le_bytes());
    let mut acc = item_from_hash(hasher.finalize());

    let mask = params.dataset_len() - 1;
    let mut index = first_u32(&acc) & mask;

    for _ in 0..params.lookups_per_hash {
        let item = dataset.get(index);
        acc = mix_step(params.variant, &acc, &item);
        index = first_u32(&acc) & mask;
    }
    acc
}

/// Same PoW computation as `mine_hash`, but for `nonces.len()` fully
/// independent chains at once, interleaved round-by-round: all `k`
/// lookups for the current round are issued before any of them is
/// consumed to compute the next index. This is what a real
/// software-pipelining miner would do to keep multiple independent
/// memory loads in flight (memory-level parallelism) instead of one
/// dependent load at a time per thread -- it is a benchmark of an
/// *attack* against the single-chain-per-thread throughput ceiling, not
/// an optimization we get to assume away. Must be byte-for-byte
/// equivalent to calling `mine_hash` separately for each nonce (see
/// `tests/consensus.rs::batched_mining_matches_single_chain_mining`) --
/// batching may only change performance, never the result.
pub fn mine_hash_batch(header: &[u8], nonces: &[u64], dataset: &Dataset, params: &Params) -> Vec<Item> {
    let k = nonces.len();
    let mask = params.dataset_len() - 1;

    let mut acc: Vec<Item> = Vec::with_capacity(k);
    let mut index: Vec<u32> = Vec::with_capacity(k);
    for &nonce in nonces {
        let mut hasher = blake3::Hasher::new();
        hasher.update(header);
        hasher.update(&nonce.to_le_bytes());
        let a = item_from_hash(hasher.finalize());
        index.push(first_u32(&a) & mask);
        acc.push(a);
    }

    let mut items: Vec<Item> = vec![[0u8; crate::item::ITEM_SIZE]; k];
    for _ in 0..params.lookups_per_hash {
        // Issue phase: k independent loads with no data dependency
        // between them -- the compiler/CPU is free to overlap them.
        for i in 0..k {
            items[i] = dataset.get(index[i]);
        }
        // Consume phase: advance each chain using its own freshly-read
        // item. Deliberately separated from the issue phase above.
        for i in 0..k {
            acc[i] = mix_step(params.variant, &acc[i], &items[i]);
            index[i] = first_u32(&acc[i]) & mask;
        }
    }
    acc
}

/// Light verification: never materializes a dataset, regenerates each
/// of the `lookups_per_hash` items on demand from `cache`. Identical
/// computation to a single cache-only mining attempt -- verification
/// cost and cache-only-mining per-hash cost are therefore the same
/// number, measured once in the benchmark suite.
pub fn verify_hash(header: &[u8], nonce: u64, cache: &Cache, params: &Params) -> Item {
    let cache_only = Dataset::cache_only(cache, params);
    mine_hash(header, nonce, &cache_only, params)
}

pub fn meets_target(hash: &Item, target: &Item) -> bool {
    // Big-endian numeric comparison of the digest against the target,
    // Bitcoin-style ("hash <= target").
    for i in 0..hash.len() {
        if hash[i] != target[i] {
            return hash[i] < target[i];
        }
    }
    true
}
