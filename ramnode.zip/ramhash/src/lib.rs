//! RamHash prototype: an experimental, RAM-bound proof-of-work
//! construction under active benchmarking. Nothing in this crate is a
//! finalized mainnet algorithm -- see
//! `docs/superpowers/specs/2026-08-17-core-rampow-consensus-design.md`
//! and `docs/dev/decisions.md` for the review that produced it and the
//! open experimental questions it's still answering.

pub mod cache;
pub mod dataset;
pub mod item;
pub mod mining;
pub mod params;
pub mod scratchpad;
pub mod variant;

pub use cache::Cache;
pub use dataset::Dataset;
pub use item::{Item, ITEM_SIZE};
pub use mining::{meets_target, mine_hash, mine_hash_batch, verify_hash};
pub use params::{Params, Variant};
pub use scratchpad::{
    fill_scratchpad, lanes_for_intensity, mine_scratchpad, mine_scratchpad_ondemand, verify_scratchpad,
    OndemandStats, ScratchpadParams,
};
