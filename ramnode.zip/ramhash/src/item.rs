/// Fixed-size dataset/cache element. 64 bytes matches Blake3's native
/// output size (2x32-byte hashes) and gives enough entropy per lookup
/// without wasting memory bandwidth on padding.
pub const ITEM_SIZE: usize = 64;

pub type Item = [u8; ITEM_SIZE];

pub fn item_from_hash(h: blake3::Hash) -> Item {
    let mut out = [0u8; ITEM_SIZE];
    // Blake3 XOF: derive ITEM_SIZE bytes from the hash instead of
    // truncating/repeating a 32-byte digest, so all 64 bytes carry
    // independent entropy.
    let mut reader = blake3::Hasher::new()
        .update(h.as_bytes())
        .finalize_xof();
    reader.fill(&mut out);
    out
}

pub fn xor_into(dst: &mut Item, src: &Item) {
    for i in 0..ITEM_SIZE {
        dst[i] ^= src[i];
    }
}

pub fn first_u32(item: &Item) -> u32 {
    u32::from_le_bytes([item[0], item[1], item[2], item[3]])
}
