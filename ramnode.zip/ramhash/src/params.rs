use crate::item::ITEM_SIZE;

/// All tunable knobs of the RamHash prototype. Nothing here is a claimed
/// mainnet value yet -- this struct exists so the benchmark harness can
/// sweep every one of these independently instead of any being baked
/// into the algorithm's code.
#[derive(Clone, Copy, Debug)]
pub struct Params {
    /// Target size of the full dataset, in bytes. Rounded down to a
    /// power-of-two number of items so index derivation can use a
    /// bitmask instead of `%`, which avoids modulo bias and is cheaper.
    pub dataset_bytes: u64,
    /// Size of the small cache used both to generate the dataset and to
    /// do on-demand item regeneration (cache-only mining, verification).
    pub cache_bytes: u64,
    /// Number of pseudo-random parent cache items mixed into a single
    /// dataset item during generation. This is the "cost multiplier"
    /// that makes on-demand generation expensive relative to a direct
    /// dataset read -- the central experimental parameter of this
    /// project. Swept across {16,32,64,128,256,512} per the review plan.
    pub dataset_parents: u32,
    /// Number of chained, data-dependent memory lookups performed per
    /// hash attempt.
    pub lookups_per_hash: u32,
    /// Which mixing construction to use between lookups. See `variant.rs`.
    pub variant: Variant,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Variant {
    /// Baseline: dependent random lookups, single uniform mixing path.
    A,
    /// Adds a data-dependent branch (2-4 distinct scalar mixing paths)
    /// per lookup, intended to be CPU-natural / GPU-hostile (warp
    /// divergence). Effectiveness is a benchmark question, not assumed.
    B,
    /// Heavier inter-lookup computational dependency (multiple ARX
    /// rounds referencing a sliding window of recent items) without
    /// adding new memory reads, to probe the compute/memory tradeoff.
    C,
    /// Diagnostic variant, not a PoW candidate: replaces the per-lookup
    /// Blake3 mix with a single cheap ARX round (add/rotate/xor/multiply,
    /// no hashing) so the hot loop's cost is dominated by the memory
    /// access itself rather than by hash-function compute. Everything
    /// else (dataset, dataset_parents, lookups_per_hash, index-selection
    /// rule, nonce handling) is unchanged from Variant A. Used to answer
    /// one question: once compute cost is minimized, does the mining
    /// loop actually become memory-bound?
    CheapMix,
}

impl Params {
    /// Number of items in the full dataset. Rounded up to a power of two
    /// (worst case ~2x the requested `dataset_bytes`) so lookups can use
    /// a bitmask instead of `%`.
    pub fn dataset_len(&self) -> u32 {
        let raw = (self.dataset_bytes / ITEM_SIZE as u64).max(1);
        raw.next_power_of_two() as u32
    }

    pub fn cache_len(&self) -> u32 {
        let raw = (self.cache_bytes / ITEM_SIZE as u64).max(1);
        raw.next_power_of_two() as u32
    }
}
