use crate::item::{item_from_hash, Item};
use crate::params::Params;

/// The small, sequentially-generated seed structure. Every dataset item
/// (whether materialized up front or regenerated on demand) is derived
/// from this. Cache generation is intentionally cheap and single-pass --
/// the expensive part of the algorithm lives in `dataset::generate_item`,
/// which is called `dataset_len` times to build the full dataset but can
/// also be called per-lookup by a miner who chose not to store the
/// dataset.
pub struct Cache {
    pub items: Vec<Item>,
}

impl Cache {
    pub fn generate(seed: &[u8], params: &Params) -> Self {
        let len = params.cache_len() as usize;
        let mut items = Vec::with_capacity(len);
        let mut prev = item_from_hash(blake3::hash(seed));
        items.push(prev);
        for i in 1..len {
            let mut hasher = blake3::Hasher::new();
            hasher.update(&prev);
            hasher.update(&(i as u64).to_le_bytes());
            prev = item_from_hash(hasher.finalize());
            items.push(prev);
        }
        Cache { items }
    }

    #[inline]
    pub fn get(&self, index: u32) -> &Item {
        // items.len() is always a power of two (see Params::cache_len),
        // so a bitmask is exact, not an approximation.
        let mask = (self.items.len() as u32) - 1;
        &self.items[(index & mask) as usize]
    }

    pub fn len(&self) -> u32 {
        self.items.len() as u32
    }
}
