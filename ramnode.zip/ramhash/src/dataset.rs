use rayon::prelude::*;

use crate::cache::Cache;
use crate::item::{first_u32, item_from_hash, Item};
use crate::params::Params;

/// Derive one full dataset item from the cache. This is the "expensive"
/// step of the algorithm: `dataset_parents` chained, cryptographically
/// mixed cache lookups. Called `dataset_len` times up front to build a
/// full dataset, or once per memory access by a miner who chose not to
/// store the dataset (cache-only mining) or by a verifier.
///
/// The cost of this function relative to a single direct dataset RAM
/// read is the central lever of the whole design: too cheap and
/// cache-only mining/on-demand regeneration becomes economically
/// rational (defeats the RAM-capacity requirement); too expensive and
/// verification becomes slow. `dataset_parents` is swept experimentally
/// to find where that line actually sits on real hardware -- see the
/// benchmark suite.
pub fn generate_item(cache: &Cache, index: u32, dataset_parents: u32) -> Item {
    let mut mix = *cache.get(index);
    mix[0] ^= (index & 0xff) as u8;
    mix[1] ^= ((index >> 8) & 0xff) as u8;
    mix[2] ^= ((index >> 16) & 0xff) as u8;
    mix[3] ^= ((index >> 24) & 0xff) as u8;

    let mut seed = first_u32(&mix) ^ index;
    for parent in 0..dataset_parents {
        seed = fnv_mix(seed, parent);
        let parent_item = cache.get(seed);

        let mut hasher = blake3::Hasher::new();
        hasher.update(&mix);
        hasher.update(parent_item);
        mix = item_from_hash(hasher.finalize());

        seed = seed.wrapping_add(first_u32(&mix));
    }
    mix
}

fn fnv_mix(a: u32, b: u32) -> u32 {
    const FNV_PRIME: u32 = 0x0100_0193;
    (a ^ b).wrapping_mul(FNV_PRIME)
}

/// How a `Dataset` actually holds (or doesn't hold) its items. This is
/// the knob the "attack benchmarks" sweep: a real miner's economic
/// choice is exactly a choice of `Storage` variant.
pub enum Storage {
    /// Every item precomputed and resident in RAM. What a rational
    /// miner does if generation cost >> RAM read cost.
    Full(Vec<Item>),
    /// Only the first `stored_len` items (out of `dataset_len`) are
    /// resident; the rest are regenerated on demand. Since lookup
    /// indices are effectively uniformly distributed over the full
    /// range regardless of which contiguous slice is stored, a prefix
    /// of size `stored_len` is statistically equivalent to a random
    /// subset of the same size for this benchmark's purposes, and much
    /// simpler to index.
    Partial { items: Vec<Item>, stored_len: u32 },
    /// Nothing precomputed; every lookup regenerates from the cache.
    /// This is both "cache-only mining" and, for a single hash attempt,
    /// exactly what a verifier does.
    CacheOnly,
}

pub struct Dataset<'a> {
    cache: &'a Cache,
    params: &'a Params,
    storage: Storage,
}

impl<'a> Dataset<'a> {
    pub fn build_full(cache: &'a Cache, params: &'a Params) -> Self {
        let len = params.dataset_len();
        let items: Vec<Item> = (0..len)
            .into_par_iter()
            .map(|i| generate_item(cache, i, params.dataset_parents))
            .collect();
        Dataset { cache, params, storage: Storage::Full(items) }
    }

    pub fn build_partial(cache: &'a Cache, params: &'a Params, fraction: f64) -> Self {
        let len = params.dataset_len();
        let stored_len = ((len as f64) * fraction.clamp(0.0, 1.0)).round() as u32;
        let items: Vec<Item> = (0..stored_len)
            .into_par_iter()
            .map(|i| generate_item(cache, i, params.dataset_parents))
            .collect();
        Dataset { cache, params, storage: Storage::Partial { items, stored_len } }
    }

    pub fn cache_only(cache: &'a Cache, params: &'a Params) -> Self {
        Dataset { cache, params, storage: Storage::CacheOnly }
    }

    #[inline]
    pub fn get(&self, index: u32) -> Item {
        let mask = self.params.dataset_len() - 1;
        let idx = index & mask;
        match &self.storage {
            Storage::Full(items) => items[idx as usize],
            Storage::Partial { items, stored_len } => {
                if idx < *stored_len {
                    items[idx as usize]
                } else {
                    generate_item(self.cache, idx, self.params.dataset_parents)
                }
            }
            Storage::CacheOnly => generate_item(self.cache, idx, self.params.dataset_parents),
        }
    }

    /// Raw bytes of a fully-materialized dataset, e.g. for uploading to
    /// a GPU storage buffer. `None` for partial/cache-only storage --
    /// those modes intentionally never hold a byte-contiguous dataset.
    pub fn full_bytes(&self) -> Option<&[u8]> {
        match &self.storage {
            Storage::Full(items) => {
                let ptr = items.as_ptr() as *const u8;
                let len = items.len() * std::mem::size_of::<Item>();
                Some(unsafe { std::slice::from_raw_parts(ptr, len) })
            }
            _ => None,
        }
    }

    pub fn resident_bytes(&self) -> u64 {
        use crate::item::ITEM_SIZE;
        match &self.storage {
            Storage::Full(items) => (items.len() * ITEM_SIZE) as u64,
            Storage::Partial { items, .. } => (items.len() * ITEM_SIZE) as u64,
            Storage::CacheOnly => 0,
        }
    }
}
