//! ScratchpadHash: an alternative RamHash construction where every
//! mining attempt gets its own **private** scratchpad instead of all
//! attempts sharing one big epoch dataset (see `dataset.rs`).
//!
//! Motivation (see docs/dev/decisions.md, 2026-08-17 "Real Blake3
//! ported to WGSL..." entry): the shared-dataset design's hashrate did
//! not scale with dataset size (more RAM did not mean more hashrate --
//! only more parallel *threads* did), and GPUs won by having thousands
//! of cheap threads sharing that one dataset, hiding memory latency
//! through sheer request-count rather than through possessing more RAM.
//! A private-per-attempt scratchpad ties achievable parallelism
//! directly to available RAM (`concurrent_lanes <= total_ram /
//! scratchpad_bytes`), and on a GPU specifically, forces each thread to
//! hold megabytes of private state that cannot fit in per-SM fast
//! memory, capping GPU occupancy the same way it's capped on CPU --
//! this is the mechanism RandomX/CryptoNight use in practice, adopted
//! here without their full random-VM complexity.
//!
//! Security-relevant property: the fill step (`fill_scratchpad`) is a
//! strictly **sequential dependent chain** (`pad[i]` derived from
//! `pad[i-1]`), not independently computable per index. This is what
//! makes "compute needed slots on demand instead of storing them" a bad
//! economic trade for a miner: reconstructing one slot at index `i`
//! costs `O(i)` (replay from the start), so unless the number of random
//! accesses needed is tiny relative to the scratchpad length, a full
//! upfront fill is cheaper than repeated on-demand reconstruction. This
//! is the same principle as `dataset.rs`'s `dataset_parents` mechanism,
//! applied per-attempt instead of per-epoch.

use crate::item::{first_u32, item_from_hash, Item, ITEM_SIZE};
use crate::variant::arx_mix;

#[derive(Clone, Copy, Debug)]
pub struct ScratchpadParams {
    /// Size of each attempt's private scratchpad, in bytes.
    pub scratchpad_bytes: u64,
    /// Number of random-access read-modify-write rounds performed
    /// after the scratchpad is filled.
    pub rounds: u32,
}

impl ScratchpadParams {
    pub fn scratchpad_len(&self) -> u32 {
        let raw = (self.scratchpad_bytes / ITEM_SIZE as u64).max(1);
        raw.next_power_of_two() as u32
    }
}

fn seed_item(header: &[u8], nonce: u64) -> Item {
    let mut hasher = blake3::Hasher::new();
    hasher.update(header);
    hasher.update(&nonce.to_le_bytes());
    item_from_hash(hasher.finalize())
}

/// Cheap, index-dependent expansion used only to give each fill step a
/// distinct second mixing input -- not a security-relevant primitive on
/// its own, just decorrelates `pad[i]` from a trivial function of `i`.
fn expand_index(i: u32) -> Item {
    let mut out = [0u8; ITEM_SIZE];
    for w in 0..16u32 {
        let v = i
            .wrapping_mul(0x9E37_79B1)
            .wrapping_add(w.wrapping_mul(0x85EB_CA77))
            ^ w.rotate_left(7);
        out[(w * 4) as usize..(w * 4 + 4) as usize].copy_from_slice(&v.to_le_bytes());
    }
    out
}

/// Sequential dependent fill: `pad[0] = seed`, `pad[i] =
/// arx_mix(pad[i-1], expand_index(i))`. Deliberately cheap per step
/// (ARX, not a hash call) -- the sequential *dependency*, not the
/// per-step cost, is what deters skipping storage (see module docs).
pub fn fill_scratchpad(seed: Item, len: u32) -> Vec<Item> {
    let mut buf = Vec::with_capacity(len as usize);
    let mut prev = seed;
    buf.push(prev);
    for i in 1..len {
        prev = arx_mix(&prev, &expand_index(i));
        buf.push(prev);
    }
    buf
}

/// One full mining attempt: seed from (header, nonce), fill a private
/// scratchpad, then `rounds` data-dependent read-modify-write random
/// accesses into it. No "light verification" mode exists for this
/// construction -- filling the scratchpad is mandatory work a verifier
/// must also perform, so `verify_scratchpad` is just this function
/// under a different name (see below).
pub fn mine_scratchpad(header: &[u8], nonce: u64, params: &ScratchpadParams) -> Item {
    let seed = seed_item(header, nonce);
    let len = params.scratchpad_len();
    let mask = len - 1;
    let mut pad = fill_scratchpad(seed, len);

    let mut acc = seed;
    let mut index = first_u32(&acc) & mask;
    for _ in 0..params.rounds {
        let item = pad[index as usize];
        let new_acc = arx_mix(&acc, &item);
        pad[index as usize] = arx_mix(&item, &new_acc); // read-modify-write
        acc = new_acc;
        index = first_u32(&acc) & mask;
    }
    acc
}

/// Verification is the identical computation -- see module docs for why
/// this construction has no cheaper light-verification path the way
/// the shared-dataset construction (`dataset.rs`) does.
pub fn verify_scratchpad(header: &[u8], nonce: u64, params: &ScratchpadParams) -> Item {
    mine_scratchpad(header, nonce, params)
}

/// Stats from `mine_scratchpad_ondemand`, for comparing the "skip the
/// upfront fill, reconstruct slots on demand" attack against honest
/// full-fill mining.
#[derive(Clone, Copy, Debug, Default)]
pub struct OndemandStats {
    /// Total sequential-chain steps executed to reconstruct requested
    /// slots (the on-demand analog of `fill_scratchpad`'s cost -- an
    /// honest miner pays exactly `scratchpad_len - 1` of these once; an
    /// on-demand attacker pays some other total depending on the access
    /// pattern and how well their cache overlaps across rounds).
    pub replay_steps: u64,
    /// The largest the sparse cache grew to -- the real peak memory an
    /// on-demand attacker needed, in items (x64 bytes), to compare
    /// against the honest miner's fixed `scratchpad_len`.
    pub peak_cache_entries: usize,
}

/// Same result as `mine_scratchpad`, computed by an attacker who never
/// allocates the full scratchpad: a sparse `BTreeMap` cache is filled
/// lazily, only replaying the sequential chain from the nearest already-
/// known predecessor up to whatever index a round actually needs. This
/// is the strongest realistic version of the "don't store it, compute
/// it on demand" attack -- it reuses every value it has ever computed
/// (including read-modify-write updates from earlier rounds), so later
/// rounds benefit from whatever the cache has already accumulated,
/// exactly like a real attacker trying to minimize replay work would.
///
/// Must produce byte-identical output to `mine_scratchpad` for the same
/// inputs (see `tests/scratchpad.rs::ondemand_matches_honest_mining`) --
/// this function may only differ in performance/memory characteristics.
pub fn mine_scratchpad_ondemand(header: &[u8], nonce: u64, params: &ScratchpadParams) -> (Item, OndemandStats) {
    let seed = seed_item(header, nonce);
    let len = params.scratchpad_len();
    let mask = len - 1;

    // Two separate structures, matching the honest algorithm's two
    // separate phases: `fill_cache` holds the ORIGINAL sequential-chain
    // value at each reconstructed index -- immutable once computed,
    // exactly what `fill_scratchpad` would have put there, and the only
    // thing ever used as a replay predecessor. `rmw_overrides` holds
    // the CURRENT value at indices a round has since read-modify-
    // written, which must never be used as a replay predecessor for
    // reconstructing *other* indices (the honest algorithm's fill phase
    // completes in full before any round runs, so later indices' fill
    // values are never influenced by an earlier round's RMW write).
    let mut fill_cache: std::collections::BTreeMap<u32, Item> = std::collections::BTreeMap::new();
    fill_cache.insert(0, seed);
    let mut rmw_overrides: std::collections::HashMap<u32, Item> = std::collections::HashMap::new();
    let mut replay_steps: u64 = 0;
    // `rmw_overrides` keys are always a subset of `fill_cache` keys (an
    // index can only be RMW-written after being fetched, and fetching
    // always leaves it in `fill_cache` first) -- so the true count of
    // distinct scratchpad slots ever touched is just `fill_cache.len()`.
    // A real attacker would use one map with in-place updates, using
    // exactly this many item-slots of memory, not `fill_cache.len() +
    // rmw_overrides.len()`.
    let mut peak = fill_cache.len();

    let mut acc = seed;
    let mut index = first_u32(&acc) & mask;
    for _ in 0..params.rounds {
        let item = if let Some(v) = rmw_overrides.get(&index) {
            *v
        } else if let Some(v) = fill_cache.get(&index) {
            *v
        } else {
            let (&start_idx, &start_val) =
                fill_cache.range(..=index).next_back().expect("index 0 is always in fill_cache");
            let mut prev = start_val;
            for i in (start_idx + 1)..=index {
                prev = arx_mix(&prev, &expand_index(i));
                fill_cache.insert(i, prev);
                replay_steps += 1;
            }
            prev
        };

        let new_acc = arx_mix(&acc, &item);
        rmw_overrides.insert(index, arx_mix(&item, &new_acc)); // read-modify-write, same as mine_scratchpad
        acc = new_acc;
        index = first_u32(&acc) & mask;
        peak = peak.max(fill_cache.len());
    }

    (acc, OndemandStats { replay_steps, peak_cache_entries: peak })
}

/// Maps a user-facing mining "intensity" level (1..=10) to a lane/thread
/// count, as a fraction of `max_available`. Level 10 always resolves to
/// exactly `max_available`; level 1 resolves to the smallest count that
/// still rounds up to at least 1 (ceiling division, not truncation, so a
/// low level on a small core count never collapses to 0 lanes).
///
/// Using genuinely fewer lanes -- not a fixed lane count throttled with
/// artificial sleeps -- is deliberate: idle lanes are idle threads, so
/// OS-level CPU/GPU utilization reporting (Task Manager, nvidia-smi)
/// reflects the real, lower workload instead of showing 100% while
/// secretly still mining full-tilt. See docs/dev/decisions.md, the
/// 2026-08-19 intensity-level entry, for the reasoning.
pub fn lanes_for_intensity(level: u8, max_available: usize) -> usize {
    let level = level.clamp(1, 10) as usize;
    let max_available = max_available.max(1);
    ((max_available * level) + 9) / 10
}
