use crate::item::Item;
use crate::params::Variant;

/// The per-lookup mixing step, dispatched by variant. This is deliberately
/// the *only* place variants A/B/C differ -- dataset generation, cache
/// generation, and the lookup-chaining loop are shared, so any measured
/// difference between variants in the benchmark suite is attributable to
/// this function alone.
pub fn mix_step(variant: Variant, acc: &Item, item: &Item) -> Item {
    match variant {
        Variant::A => blake_mix(acc, item),
        Variant::CheapMix => arx_mix(acc, item),
        Variant::B => {
            // Branch condition depends on freshly-read memory (`item`),
            // which is not known until the preceding dependent lookup
            // completes -- a compiler cannot predicate this away at
            // compile time, and a GPU thread cannot know which path a
            // sibling thread in its warp will take until runtime either.
            // Whether that actually costs GPU throughput anything is an
            // empirical question for the benchmark, not assumed here.
            match item[0] & 0b11 {
                0 => blake_mix(acc, item),
                1 => arx_mix(acc, item),
                2 => blake_mix(item, acc),
                _ => arx_mix(item, acc),
            }
        }
        Variant::C => {
            // Heavier computational dependency between lookups without
            // any additional memory access: one hash mix followed by
            // several ARX rounds chained on its own output.
            let mut m = blake_mix(acc, item);
            for _ in 0..4 {
                m = arx_mix(&m, item);
            }
            m
        }
    }
}

fn blake_mix(a: &Item, b: &Item) -> Item {
    let mut hasher = blake3::Hasher::new();
    hasher.update(a);
    hasher.update(b);
    crate::item::item_from_hash(hasher.finalize())
}

/// Add-Rotate-XOR mixing over 8x u64 words. Not a cryptographic
/// primitive in its own right -- a cheap, scalar-integer-only path
/// chosen to be instruction-mix-distinct from `blake_mix`, so Variant
/// B/C branches diverge in actually-executed work, not just in which
/// hash function gets called.
pub(crate) fn arx_mix(a: &Item, b: &Item) -> Item {
    const GOLDEN: u64 = 0x9E37_79B9_7F4A_7C15;
    let mut wa = to_u64x8(a);
    let wb = to_u64x8(b);
    for i in 0..8 {
        wa[i] = wa[i].wrapping_add(wb[i]);
        wa[i] = wa[i].rotate_left(13) ^ wb[(i + 3) % 8];
        wa[i] = wa[i].wrapping_mul(GOLDEN);
        wa[i] ^= wa[i] >> 29;
    }
    from_u64x8(wa)
}

fn to_u64x8(item: &Item) -> [u64; 8] {
    let mut out = [0u64; 8];
    for (i, chunk) in item.chunks_exact(8).enumerate() {
        out[i] = u64::from_le_bytes(chunk.try_into().unwrap());
    }
    out
}

fn from_u64x8(words: [u64; 8]) -> Item {
    let mut out = [0u8; 64];
    for (i, w) in words.iter().enumerate() {
        out[i * 8..i * 8 + 8].copy_from_slice(&w.to_le_bytes());
    }
    out
}
