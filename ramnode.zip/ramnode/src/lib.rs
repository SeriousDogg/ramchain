use std::fs::{self, OpenOptions};
use std::io::{self, Write};
use std::path::Path;
use std::time::{SystemTime, UNIX_EPOCH};

use ramchain::protocol::{JobResponse, StatusResponse, SubmitRequest, SubmitResponse};
use ramchain::{validate_next_block, Block, BlockHeader};
use ramhash::{Item, ScratchpadParams};

pub struct ChainState {
    blocks: Vec<Block>,
    current_job: BlockHeader,
    params: ScratchpadParams,
    target: Item,
    difficulty_bits: u32,
    file: fs::File,
}

pub fn now_unix() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .expect("system clock is before the unix epoch")
        .as_secs()
}

impl ChainState {
    /// Loads an existing chain from `chain_file` (one JSON `Block` per
    /// line) if it exists, or creates a genesis block and writes it as
    /// the file's first line if it doesn't.
    pub fn load_or_init(
        chain_file: &str,
        target: Item,
        params: ScratchpadParams,
        difficulty_bits: u32,
    ) -> io::Result<ChainState> {
        let path = Path::new(chain_file);
        let existing: Vec<Block> = if path.exists() {
            let content = fs::read_to_string(path)?;
            content
                .lines()
                .filter(|l| !l.trim().is_empty())
                .map(|l| serde_json::from_str(l).expect("corrupt chain file line"))
                .collect()
        } else {
            Vec::new()
        };

        let mut file = OpenOptions::new().create(true).append(true).open(path)?;

        let blocks = if existing.is_empty() {
            let genesis = ramchain::genesis_block(target, &params);
            writeln!(file, "{}", serde_json::to_string(&genesis).expect("Block always serializes"))?;
            file.flush()?;
            vec![genesis]
        } else {
            existing
        };

        let tip = blocks.last().expect("blocks is never empty at this point").clone();
        let current_job = BlockHeader { height: tip.header.height + 1, prev_hash: tip.hash, timestamp: now_unix(), target };

        Ok(ChainState { blocks, current_job, params, target, difficulty_bits, file })
    }

    pub fn tip(&self) -> &Block {
        self.blocks.last().expect("chain always has at least genesis")
    }

    pub fn height(&self) -> u64 {
        self.tip().header.height
    }

    pub fn recompute_job(&mut self) {
        let tip = self.tip();
        self.current_job =
            BlockHeader { height: tip.header.height + 1, prev_hash: tip.hash, timestamp: now_unix(), target: self.target };
    }

    fn append_block(&mut self, block: Block) -> io::Result<()> {
        writeln!(self.file, "{}", serde_json::to_string(&block).expect("Block always serializes"))?;
        self.file.flush()?;
        self.blocks.push(block);
        Ok(())
    }

    pub fn job_response(&self) -> JobResponse {
        JobResponse {
            height: self.current_job.height,
            prev_hash: self.current_job.prev_hash,
            timestamp: self.current_job.timestamp,
            target: self.current_job.target,
            scratchpad_bytes: self.params.scratchpad_bytes,
            rounds: self.params.rounds,
        }
    }

    pub fn status_response(&self) -> StatusResponse {
        StatusResponse { height: self.height(), tip_hash: self.tip().hash, difficulty_bits: self.difficulty_bits }
    }

    /// Validates `req` against the current tip and, if it extends the
    /// chain correctly, appends and persists the new block and
    /// recomputes the next job. Always returns a response reflecting
    /// the chain's height *after* this call, whether or not `req` was
    /// accepted.
    pub fn handle_submit(&mut self, req: &SubmitRequest) -> SubmitResponse {
        let tip = self.tip().clone();
        let header = BlockHeader { height: req.height, prev_hash: req.prev_hash, timestamp: req.timestamp, target: self.target };
        match validate_next_block(&tip, &header, req.nonce, &self.params) {
            Ok(block) => {
                self.append_block(block).expect("failed to persist an accepted block");
                self.recompute_job();
                SubmitResponse { accepted: true, height: self.height(), reason: None }
            }
            Err(e) => SubmitResponse { accepted: false, height: self.height(), reason: Some(format!("{e:?}")) },
        }
    }
}
