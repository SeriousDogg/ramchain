use std::sync::Mutex;

use clap::Parser;
use ramchain::protocol::SubmitRequest;
use ramnode::ChainState;
use serde::Serialize;

#[derive(Parser)]
struct Cli {
    /// Port to listen on (bind address is always 0.0.0.0).
    #[arg(long, default_value_t = 7878)]
    port: u16,
    /// Shared secret every request must present as `Authorization: Bearer <token>`.
    #[arg(long)]
    token: String,
    /// Fixed difficulty: number of leading zero bits the target has.
    #[arg(long, default_value_t = 20)]
    difficulty_bits: u32,
    /// Append-only chain persistence file.
    #[arg(long, default_value = "chain.jsonl")]
    chain_file: String,
    #[arg(long, default_value_t = 4.0)]
    scratchpad_mb: f64,
    #[arg(long, default_value_t = 40_000)]
    rounds: u32,
}

fn main() {
    let cli = Cli::parse();
    let target = ramchain::target_from_leading_zero_bits(cli.difficulty_bits);
    let params = ramhash::ScratchpadParams { scratchpad_bytes: (cli.scratchpad_mb * 1024.0 * 1024.0) as u64, rounds: cli.rounds };

    let mut state = ChainState::load_or_init(&cli.chain_file, target, params, cli.difficulty_bits)
        .expect("failed to load or initialize the chain file");
    state.recompute_job();
    println!("ramnode listening on 0.0.0.0:{} -- height={} difficulty_bits={}", cli.port, state.height(), cli.difficulty_bits);
    let state = Mutex::new(state);

    let server = tiny_http::Server::http(("0.0.0.0", cli.port)).expect("failed to bind HTTP server");
    for request in server.incoming_requests() {
        handle_request(&state, &cli.token, request);
    }
}

fn handle_request(state: &Mutex<ChainState>, token: &str, mut request: tiny_http::Request) {
    if !auth_ok(&request, token) {
        respond_text(request, 401, "unauthorized");
        return;
    }

    match (request.method().clone(), request.url().to_string()) {
        (tiny_http::Method::Get, url) if url == "/job" => {
            let job = state.lock().expect("chain state lock poisoned").job_response();
            respond_json(request, 200, &job);
        }
        (tiny_http::Method::Get, url) if url == "/status" => {
            let status = state.lock().expect("chain state lock poisoned").status_response();
            respond_json(request, 200, &status);
        }
        (tiny_http::Method::Post, url) if url == "/submit" => {
            let mut body = String::new();
            if let Err(e) = request.as_reader().read_to_string(&mut body) {
                respond_text(request, 400, &format!("failed to read request body: {e}"));
                return;
            }
            let req: SubmitRequest = match serde_json::from_str(&body) {
                Ok(r) => r,
                Err(e) => {
                    respond_text(request, 400, &format!("invalid submit JSON: {e}"));
                    return;
                }
            };
            let resp = state.lock().expect("chain state lock poisoned").handle_submit(&req);
            println!("submit: height={} accepted={} reason={:?}", req.height, resp.accepted, resp.reason);
            respond_json(request, 200, &resp);
        }
        _ => respond_text(request, 404, "not found"),
    }
}

fn auth_ok(request: &tiny_http::Request, token: &str) -> bool {
    let expected = format!("Bearer {token}");
    request.headers().iter().any(|h| h.field.equiv("Authorization") && h.value.as_str() == expected.as_str())
}

fn respond_text(request: tiny_http::Request, status: u16, body: &str) {
    let _ = request.respond(tiny_http::Response::from_string(body.to_string()).with_status_code(status));
}

fn respond_json<T: Serialize>(request: tiny_http::Request, status: u16, body: &T) {
    let json = serde_json::to_string(body).expect("response DTO always serializes");
    let header = tiny_http::Header::from_bytes(&b"Content-Type"[..], &b"application/json"[..]).expect("static header is valid");
    let response = tiny_http::Response::from_string(json).with_status_code(status).with_header(header);
    let _ = request.respond(response);
}
