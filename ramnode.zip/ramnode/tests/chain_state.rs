use ramchain::protocol::SubmitRequest;
use ramchain::{header_bytes, target_from_leading_zero_bits, BlockHeader};
use ramhash::{mine_scratchpad, ScratchpadParams};
use ramnode::ChainState;

fn test_params() -> ScratchpadParams {
    ScratchpadParams { scratchpad_bytes: 1 << 16, rounds: 32 }
}

fn tmp_path(name: &str) -> std::path::PathBuf {
    let mut p = std::env::temp_dir();
    p.push(format!("ramnode_test_{name}_{}.jsonl", std::process::id()));
    let _ = std::fs::remove_file(&p);
    p
}

#[test]
fn fresh_file_creates_genesis() {
    let path = tmp_path("fresh_genesis");
    let target = target_from_leading_zero_bits(0);
    let state = ChainState::load_or_init(path.to_str().unwrap(), target, test_params(), 0).unwrap();
    assert_eq!(state.height(), 0);
    let _ = std::fs::remove_file(&path);
}

#[test]
fn valid_submission_advances_chain_and_persists() {
    let path = tmp_path("advance");
    let target = target_from_leading_zero_bits(0); // trivial: any hash meets it
    let params = test_params();
    let mut state = ChainState::load_or_init(path.to_str().unwrap(), target, params, 0).unwrap();
    let job = state.job_response();

    let header = BlockHeader { height: job.height, prev_hash: job.prev_hash, timestamp: job.timestamp, target: job.target };
    let nonce = 0u64;
    let hash = mine_scratchpad(&header_bytes(&header), nonce, &params);
    assert!(ramhash::meets_target(&hash, &job.target), "test setup assumption broken: nonce 0 should meet a trivial target");

    let req = SubmitRequest { height: job.height, prev_hash: job.prev_hash, timestamp: job.timestamp, nonce };
    let resp = state.handle_submit(&req);
    assert!(resp.accepted, "expected acceptance, got {:?}", resp.reason);
    assert_eq!(resp.height, 1);
    assert_eq!(state.height(), 1);

    let reloaded = ChainState::load_or_init(path.to_str().unwrap(), target, params, 0).unwrap();
    assert_eq!(reloaded.height(), 1, "chain must survive a reload from disk");
    let _ = std::fs::remove_file(&path);
}

#[test]
fn stale_submission_is_rejected_and_does_not_advance_chain() {
    let path = tmp_path("stale");
    let target = target_from_leading_zero_bits(0);
    let params = test_params();
    let mut state = ChainState::load_or_init(path.to_str().unwrap(), target, params, 0).unwrap();
    let req = SubmitRequest { height: 5, prev_hash: [0u8; 64], timestamp: 0, nonce: 0 };
    let resp = state.handle_submit(&req);
    assert!(!resp.accepted);
    assert_eq!(state.height(), 0);
    let _ = std::fs::remove_file(&path);
}
