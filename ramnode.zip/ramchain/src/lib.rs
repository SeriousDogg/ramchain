//! RamCoin testnet v0: block/chain data model, validation, and the
//! wire protocol shared between `ramnode` and `ramminer`. See
//! docs/superpowers/specs/2026-08-19-testnet-node-and-miner-design.md.

pub mod block;
pub mod difficulty;
pub mod protocol;

pub use block::{genesis_block, header_bytes, validate_next_block, Block, BlockHeader, ValidationError, GENESIS_TIMESTAMP};
pub use difficulty::target_from_leading_zero_bits;
