use ramhash::{meets_target, mine_scratchpad, Item, ITEM_SIZE};
use serde::{Deserialize, Serialize};

use crate::protocol::item_hex;

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct BlockHeader {
    pub height: u64,
    #[serde(with = "item_hex")]
    pub prev_hash: Item,
    pub timestamp: u64,
    #[serde(with = "item_hex")]
    pub target: Item,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Block {
    pub header: BlockHeader,
    pub nonce: u64,
    #[serde(with = "item_hex")]
    pub hash: Item,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ValidationError {
    WrongHeight { expected: u64, got: u64 },
    WrongPrevHash,
    TimestampNotMonotonic,
    DoesNotMeetTarget,
}

/// The exact bytes fed as the `header` argument to `mine_scratchpad` --
/// the one place this serialization is defined, shared by every
/// consumer (validation here, `ramnode`, `ramminer`) so they can never
/// silently disagree on it.
pub fn header_bytes(header: &BlockHeader) -> Vec<u8> {
    let mut buf = Vec::with_capacity(8 + ITEM_SIZE + 8 + ITEM_SIZE);
    buf.extend_from_slice(&header.height.to_le_bytes());
    buf.extend_from_slice(&header.prev_hash);
    buf.extend_from_slice(&header.timestamp.to_le_bytes());
    buf.extend_from_slice(&header.target);
    buf
}

/// Fixed constant (2025-08-19T08:00:00Z), arbitrary but fixed -- every
/// node building a fresh chain from genesis must use the same value.
pub const GENESIS_TIMESTAMP: u64 = 1755590400;

/// Genesis is the hardcoded trust anchor: exempt from the PoW check
/// (nonce = 0, hash computed but not required to meet `target`), same
/// as every real chain's genesis block.
pub fn genesis_block(target: Item, params: &ramhash::ScratchpadParams) -> Block {
    let header = BlockHeader { height: 0, prev_hash: [0u8; ITEM_SIZE], timestamp: GENESIS_TIMESTAMP, target };
    let hash = mine_scratchpad(&header_bytes(&header), 0, params);
    Block { header, nonce: 0, hash }
}

pub fn validate_next_block(
    tip: &Block,
    header: &BlockHeader,
    nonce: u64,
    params: &ramhash::ScratchpadParams,
) -> Result<Block, ValidationError> {
    if header.height != tip.header.height + 1 {
        return Err(ValidationError::WrongHeight { expected: tip.header.height + 1, got: header.height });
    }
    if header.prev_hash != tip.hash {
        return Err(ValidationError::WrongPrevHash);
    }
    if header.timestamp < tip.header.timestamp {
        return Err(ValidationError::TimestampNotMonotonic);
    }
    let hash = mine_scratchpad(&header_bytes(header), nonce, params);
    if !meets_target(&hash, &header.target) {
        return Err(ValidationError::DoesNotMeetTarget);
    }
    Ok(Block { header: header.clone(), nonce, hash })
}
