use ramhash::{Item, ITEM_SIZE};

/// Returns the largest 512-bit value (as a big-endian `Item`) with
/// `bits` leading zero bits. A simplified analog of Bitcoin's nBits --
/// a single tunable integer instead of a compact-float encoding,
/// appropriate since this testnet's difficulty is fixed at node
/// startup rather than automatically retargeted. More `bits` means a
/// numerically smaller (harder) target, matching `ramhash::meets_target`'s
/// big-endian "hash <= target" rule.
pub fn target_from_leading_zero_bits(bits: u32) -> Item {
    let bits = bits.min((ITEM_SIZE as u32) * 8);
    let mut t = [0xFFu8; ITEM_SIZE];
    let full_bytes = (bits / 8) as usize;
    let rem_bits = bits % 8;
    for b in t.iter_mut().take(full_bytes) {
        *b = 0x00;
    }
    if full_bytes < ITEM_SIZE && rem_bits > 0 {
        t[full_bytes] = 0xFFu8 >> rem_bits;
    }
    t
}
