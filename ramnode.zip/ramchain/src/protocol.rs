use ramhash::{Item, ITEM_SIZE};
use serde::{Deserialize, Deserializer, Serialize, Serializer};

/// `#[serde(with = "item_hex")]` helper: serializes an `Item` ([u8; 64])
/// as a 128-character lowercase hex string instead of a JSON array of
/// 64 numbers, and validates length on the way back in.
pub mod item_hex {
    use super::*;

    pub fn serialize<S: Serializer>(item: &Item, s: S) -> Result<S::Ok, S::Error> {
        s.serialize_str(&hex::encode(item))
    }

    pub fn deserialize<'de, D: Deserializer<'de>>(d: D) -> Result<Item, D::Error> {
        let s = String::deserialize(d)?;
        let bytes = hex::decode(&s).map_err(serde::de::Error::custom)?;
        if bytes.len() != ITEM_SIZE {
            return Err(serde::de::Error::custom(format!(
                "expected {ITEM_SIZE} bytes ({} hex chars), got {} bytes",
                ITEM_SIZE * 2,
                bytes.len()
            )));
        }
        let mut out = [0u8; ITEM_SIZE];
        out.copy_from_slice(&bytes);
        Ok(out)
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct JobResponse {
    pub height: u64,
    #[serde(with = "item_hex")]
    pub prev_hash: Item,
    pub timestamp: u64,
    #[serde(with = "item_hex")]
    pub target: Item,
    pub scratchpad_bytes: u64,
    pub rounds: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SubmitRequest {
    pub height: u64,
    #[serde(with = "item_hex")]
    pub prev_hash: Item,
    pub timestamp: u64,
    pub nonce: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SubmitResponse {
    pub accepted: bool,
    pub height: u64,
    pub reason: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StatusResponse {
    pub height: u64,
    #[serde(with = "item_hex")]
    pub tip_hash: Item,
    pub difficulty_bits: u32,
}
