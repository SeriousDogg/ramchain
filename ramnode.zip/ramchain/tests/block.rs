use ramchain::{genesis_block, header_bytes, target_from_leading_zero_bits, validate_next_block, BlockHeader, ValidationError};
use ramhash::{mine_scratchpad, ScratchpadParams};

fn test_params() -> ScratchpadParams {
    ScratchpadParams { scratchpad_bytes: 1 << 16, rounds: 32 }
}

#[test]
fn genesis_is_internally_consistent() {
    let target = target_from_leading_zero_bits(0);
    let params = test_params();
    let genesis = genesis_block(target, &params);
    assert_eq!(genesis.header.height, 0);
    assert_eq!(genesis.header.prev_hash, [0u8; 64]);
    assert_eq!(genesis.nonce, 0);
    let expected_hash = mine_scratchpad(&header_bytes(&genesis.header), 0, &params);
    assert_eq!(genesis.hash, expected_hash);
}

#[test]
fn correctly_mined_next_block_validates() {
    let target = target_from_leading_zero_bits(0); // trivial: every hash meets it
    let params = test_params();
    let tip = genesis_block(target, &params);

    let header = BlockHeader { height: 1, prev_hash: tip.hash, timestamp: tip.header.timestamp + 1, target };
    let nonce = 0u64;
    let result = validate_next_block(&tip, &header, nonce, &params);
    assert!(result.is_ok(), "expected Ok, got {result:?}");
    let block = result.unwrap();
    assert_eq!(block.header.height, 1);
    assert_eq!(block.nonce, nonce);
}

#[test]
fn wrong_height_is_rejected() {
    let target = target_from_leading_zero_bits(0);
    let params = test_params();
    let tip = genesis_block(target, &params);
    let header = BlockHeader { height: 5, prev_hash: tip.hash, timestamp: tip.header.timestamp + 1, target };
    let result = validate_next_block(&tip, &header, 0, &params);
    assert!(matches!(result, Err(ValidationError::WrongHeight { expected: 1, got: 5 })), "got {result:?}");
}

#[test]
fn wrong_prev_hash_is_rejected() {
    let target = target_from_leading_zero_bits(0);
    let params = test_params();
    let tip = genesis_block(target, &params);
    let header = BlockHeader { height: 1, prev_hash: [0x77u8; 64], timestamp: tip.header.timestamp + 1, target };
    let result = validate_next_block(&tip, &header, 0, &params);
    assert!(matches!(result, Err(ValidationError::WrongPrevHash)), "got {result:?}");
}

#[test]
fn non_monotonic_timestamp_is_rejected() {
    let target = target_from_leading_zero_bits(0);
    let params = test_params();
    let tip = genesis_block(target, &params);
    let header = BlockHeader { height: 1, prev_hash: tip.hash, timestamp: tip.header.timestamp - 1, target };
    let result = validate_next_block(&tip, &header, 0, &params);
    assert!(matches!(result, Err(ValidationError::TimestampNotMonotonic)), "got {result:?}");
}

#[test]
fn hash_not_meeting_target_is_rejected() {
    let easy_target = target_from_leading_zero_bits(0);
    let params = test_params();
    let tip = genesis_block(easy_target, &params);

    // Near-impossible target: only a hash of essentially all-zero bytes
    // could meet it -- a real hash output won't, for any small nonce.
    let hard_target = target_from_leading_zero_bits(511);
    let header = BlockHeader { height: 1, prev_hash: tip.hash, timestamp: tip.header.timestamp + 1, target: hard_target };
    let result = validate_next_block(&tip, &header, 0, &params);
    assert!(matches!(result, Err(ValidationError::DoesNotMeetTarget)), "got {result:?}");
}
