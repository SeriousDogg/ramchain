use ramchain::target_from_leading_zero_bits;

#[test]
fn zero_bits_gives_max_target() {
    let t = target_from_leading_zero_bits(0);
    assert_eq!(t, [0xFFu8; 64]);
}

#[test]
fn eight_bits_zeroes_first_byte_only() {
    let t = target_from_leading_zero_bits(8);
    assert_eq!(t[0], 0x00);
    assert_eq!(t[1], 0xFF);
    assert_eq!(t[63], 0xFF);
}

#[test]
fn four_bits_zeroes_high_nibble_of_first_byte() {
    let t = target_from_leading_zero_bits(4);
    assert_eq!(t[0], 0x0F);
    assert_eq!(t[1], 0xFF);
}

#[test]
fn full_512_bits_gives_all_zero_target() {
    let t = target_from_leading_zero_bits(512);
    assert_eq!(t, [0x00u8; 64]);
}

#[test]
fn more_bits_means_smaller_numeric_target() {
    let easy = target_from_leading_zero_bits(4);
    let hard = target_from_leading_zero_bits(20);
    assert!(hard < easy);
}
