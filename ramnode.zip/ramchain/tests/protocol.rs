use ramchain::protocol::{JobResponse, StatusResponse, SubmitRequest, SubmitResponse};

#[test]
fn job_response_round_trips_through_json() {
    let job = JobResponse {
        height: 7,
        prev_hash: [0xABu8; 64],
        timestamp: 1755600000,
        target: [0xFFu8; 64],
        scratchpad_bytes: 4 * 1024 * 1024,
        rounds: 40_000,
    };
    let json = serde_json::to_string(&job).unwrap();
    let back: JobResponse = serde_json::from_str(&json).unwrap();
    assert_eq!(job.height, back.height);
    assert_eq!(job.prev_hash, back.prev_hash);
    assert_eq!(job.target, back.target);
    assert_eq!(job.scratchpad_bytes, back.scratchpad_bytes);
    assert_eq!(job.rounds, back.rounds);
}

#[test]
fn item_hex_encodes_as_128_char_lowercase_hex_string() {
    let job = JobResponse {
        height: 0,
        prev_hash: [0x00u8; 64],
        timestamp: 0,
        target: [0xFFu8; 64],
        scratchpad_bytes: 1,
        rounds: 1,
    };
    let json = serde_json::to_string(&job).unwrap();
    assert!(json.contains(&"0".repeat(128)), "prev_hash should serialize as 128 zero hex chars: {json}");
    assert!(json.contains(&"f".repeat(128)), "target should serialize as 128 'f' hex chars: {json}");
}

#[test]
fn submit_request_round_trips() {
    let req = SubmitRequest { height: 3, prev_hash: [0x11u8; 64], timestamp: 42, nonce: 987654321 };
    let json = serde_json::to_string(&req).unwrap();
    let back: SubmitRequest = serde_json::from_str(&json).unwrap();
    assert_eq!(req.height, back.height);
    assert_eq!(req.prev_hash, back.prev_hash);
    assert_eq!(req.timestamp, back.timestamp);
    assert_eq!(req.nonce, back.nonce);
}

#[test]
fn submit_response_with_none_reason_round_trips() {
    let resp = SubmitResponse { accepted: true, height: 5, reason: None };
    let json = serde_json::to_string(&resp).unwrap();
    let back: SubmitResponse = serde_json::from_str(&json).unwrap();
    assert_eq!(back.accepted, true);
    assert_eq!(back.height, 5);
    assert_eq!(back.reason, None);
}

#[test]
fn status_response_round_trips() {
    let status = StatusResponse { height: 9, tip_hash: [0x22u8; 64], difficulty_bits: 20 };
    let json = serde_json::to_string(&status).unwrap();
    let back: StatusResponse = serde_json::from_str(&json).unwrap();
    assert_eq!(status.height, back.height);
    assert_eq!(status.tip_hash, back.tip_hash);
    assert_eq!(status.difficulty_bits, back.difficulty_bits);
}
